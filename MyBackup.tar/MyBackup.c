#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include "time.h"
#include <sys/types.h>
#include <linux/inotify.h>
#include <sys/mman.h>

#include <sys/stat.h>

#define NAME_MAX 255
#define REV "rev"

char* backupDir = "./tmp";
bool metaDup = true;
bool timeLabel = false;

char* targetFile;  // the absolute path of the watching file
char* targetFileName;

int inotifyFD;
#define BUF_LEN (10 * (sizeof(struct inotify_event) + NAME_MAX + 1))

int versionCounter = 0;

void print_usage() {

	printf(
			"Usage: MyBackup -[options] value... targetFilePath \n"
					"\t-h display this help message.\n"
					"\t-d [location directory] option can be used to customize the backup location.\n"
					"\t-m option can be used to disable meta-data duplication.\n"
					"\t-t option can append the duplication time to the file name.\n");
}

bool file_exists(char *file_name) {
	FILE *file_ptr = fopen(file_name, "r");

	if (!file_ptr) {
		return false;
	}

	return true;
}

int lastIndexOf(const char * s, char target) {
	int ret = -1;
	int curIdx = 0;
	while (s[curIdx] != '\0') {
		if (s[curIdx] == target)
			ret = curIdx;
		curIdx++;
	}
	return ret;
}

void get_target_file_name() {
	int MAXSIZE = 0xFFF;
	char proclnk[0xFFF];
	char filename[0xFFF];
	FILE *fp;
	int fno;
	ssize_t r;

	// test.txt created earlier
	fp = fopen(targetFile, "r");
	if (fp != NULL) {
		fno = fileno(fp);
		sprintf(proclnk, "/proc/self/fd/%d", fno);
		r = readlink(proclnk, filename, MAXSIZE);
		if (r < 0) {
			printf("failed to readlink\n");
			exit(1);
		}
		filename[r] = '\0';
		printf("fp -> fno -> filename: %p -> %d -> %s\n", fp, fno, filename);
	}

	int fileNameStartIndex = lastIndexOf(filename, '/');
	char tmp[0xFFF];
	memcpy(tmp, &filename[fileNameStartIndex + 1], r - fileNameStartIndex + 1);
	printf("target filepath = %s\n", filename);
	printf("target filename = %s\n", tmp);
//	return tmp;
	targetFileName = malloc(MAXSIZE);
	memcpy(targetFileName, tmp, r - fileNameStartIndex + 1);
}

bool command_line_parser(int argc, char *argv[]) {

	if (argc == 1) {
		perror("You must specify the target file!");
		print_usage();
		exit(EXIT_FAILURE);
	}
	int opt;

	while ((opt = getopt(argc, argv, "hdmt")) != -1) {
		switch (opt) {
		case 'd':
			if (optarg == NULL) {
				perror("you must specify a directory path for the '-d' option");
				exit(EXIT_FAILURE);
			}
			struct stat s;
			int err = stat("/path/to/possible_dir", &s);
			if (-1 == err) {
				perror("The directory you specified does not exist!");
				exit(1);
			} else {
				if (S_ISDIR(s.st_mode)) {
					backupDir = optarg;
				} else {
					/* exists but is no dir */
					perror("You must specify a directory but not a file!");
					exit(1);
				}
			}
			break;
		case 'm':
			metaDup = false;
			break;
		case 't':
			timeLabel = true;
			break;
		case 'h':
			print_usage();
			exit(EXIT_FAILURE);
			break;
		default:
			print_usage();
			exit(EXIT_FAILURE);
		}
	}

	if (optind < argc) {
		do {
			targetFile = argv[optind];
			// do something with file
		} while (++optind < argc);

		if (!file_exists(targetFile)) {
			perror("The file you specified does not exist, please check it!");
			exit(1);
		} else {
			printf("File exists!\n");
			get_target_file_name();
//			printf(targetFileName);
		}
	} else {
		perror("You must specify the target file!");
		exit(1);
	}
}

char* get_formatted_time_label() {
	time_t timer;
	char* dupTime = malloc(26);

	struct tm* tm_info;

	time(&timer);
	tm_info = localtime(&timer);

	strftime(dupTime, 26, "%Y%m%d%H%M%S", tm_info);
	return dupTime;
}

void initialize_inotify() {
	inotifyFD = inotify_init();

	/*checking for error*/
	if (inotifyFD < 0) {
		perror("inotify_init");
	}
	int wd = inotify_add_watch(inotifyFD, targetFile,
	IN_MODIFY | IN_DELETE_SELF);
	if (wd == -1) {
		perror("inotify_add_watch");
		exit(1);
	}

	printf("Watching %s using wd %d\n", targetFile, wd);
}

char* obtain_backup_name() {
//	backupDir

	char* filename = malloc(0xFFF);
	strcpy(filename, targetFileName);
	if (timeLabel) {
		strcat(filename, "_");
		strcat(filename, get_formatted_time_label());
	}

	strcat(filename, "_");
	strcat(filename, REV);

	char integer_string[32];
	sprintf(integer_string, "%d", versionCounter);
	strcat(filename, integer_string);
	versionCounter++;
	return filename;
}

void conduct_copy() {
	char* newbackupFilePath = obtain_backup_name();
	char* fullpath = malloc(0xFFF);
	strcpy(fullpath, backupDir);
	int size = strlen(backupDir);
	if (fullpath[size - 1] != '/')
		strcat(fullpath, "/");
	strcat(fullpath, newbackupFilePath);
	printf("Automatically backup the file %s into %s.\n", targetFile, fullpath);
	if (metaDup) {
		//do deep copy
		deep_copy(fullpath, targetFile);
	} else {
		//do shallow copy
		shallow_copy(fullpath, targetFile);
	}
	free(fullpath);
	free(newbackupFilePath);
}

void watching_processing() {

	conduct_copy();
	char buf[BUF_LEN] __attribute__ ((aligned(8)));
	struct inotify_event *event;
	ssize_t numRead;
	char *p;

	for (;;) { /* Read events forever */
		numRead = read(inotifyFD, buf, BUF_LEN);
		if (numRead == 0) {
			perror("read() from inotify fd returned 0!");
		}

		if (numRead == -1) {
			perror("read");
			exit(1);
		}

		printf("Read %ld bytes from inotify fd\n", (long) numRead);

		/* Process all of the events in buffer returned by read() */
//		int eventI = 0;
//		for (; eventI < numRead;) {
//			struct inotify_event *event = (struct inotify_event *) &buf[eventI];

		for (p = buf; p < buf + numRead;) {
			event = (struct inotify_event *) p;
			//event processing
			if (event->mask & IN_MODIFY) {
				conduct_copy();
			}

			if (event->mask & IN_DELETE_SELF) {
				printf("The file %s is deleted, the MyBackup finished!.\n",
						targetFile);
				exit(0);
			}
//			printf("p = %d, buf = %d, size = %d, len = %d\n", p, buf, sizeof(struct inotify_event), event->len);
			p += sizeof(struct inotify_event) + event->len;
//			printf("i = %d, buf = %d, size = %d, len = %d", eventI, buf,
//					sizeof(struct inotify_event), event->len);
//			eventI += sizeof(struct inotify_event) + event->len;
		}
//		printf("finished one round\n");
	}
}

void deep_copy(char *out_str, char *in_str) {
	int fdin, fdout;
	char *src, *dst;
	struct stat statbuf;

	/* open the input file */
	if ((fdin = open(in_str, O_RDONLY)) < 0)
		printf("can't open %s for reading", in_str);

	/* open/create the output file */
	if ((fdout = open(out_str, O_RDWR | O_CREAT | O_TRUNC)) < 0)
		printf("can't create %s for writing", out_str);

	/* find size of input file */
	if (fstat(fdin, &statbuf) < 0)
		perror("fstat error");

	/* go to the location corresponding to the last byte */
	if (lseek(fdout, statbuf.st_size - 1, SEEK_SET) == -1)
		perror("lseek error");

	/* write a dummy byte at the last location */
	if (write(fdout, "", 1) != 1)
		perror("write error");

	/* mmap the input file */
	if ((src = mmap(0, statbuf.st_size, PROT_READ, MAP_SHARED, fdin, 0))
			== (caddr_t) -1)
		perror("mmap error for input");

	/* mmap the output file */
	if ((dst = mmap(0, statbuf.st_size, PROT_READ | PROT_WRITE,
	MAP_SHARED, fdout, 0)) == (caddr_t) -1)
		perror("mmap error for output");

	/* this copies the input file to the output file */
	memcpy(dst, src, statbuf.st_size);
}

void shallow_copy(char *out_str, char *in_str) {
	// int c to store one char at a time
	int c;

	// declare and open files for copy
	FILE *in_ptr = fopen(in_str, "r");
	FILE *out_ptr = fopen(out_str, "w");

	if (!in_ptr) {
		perror("Source file can't be opened: ");
		exit(1);
	}

	if (!out_ptr) {
		perror("Destination file can't be opened: ");
		exit(1);
	}

	// copy file one char at a time
	while ((c = fgetc(in_ptr)) != EOF) {
		fputc(c, out_ptr);
	}

	// success
	printf("\nSuccess!\n");

	// close files
	fclose(in_ptr);
	fclose(out_ptr);
}

int main(int argc, char *argv[]) {
//    prompt_user();
	int argcTmp = 3;
//	const char *options[3] = { "-b ./testfile1", "-m", "dfasfda" };
	command_line_parser(argc, argv);
	initialize_inotify();
	watching_processing();
	return EXIT_SUCCESS;
}
